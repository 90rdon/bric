<?php
/*



Template name: Custom Broker Toolbox Delete Page



*/
ob_start();
get_header(); 
if(!$_SESSION['is_login']) {
header("Location:/agent-login");
exit;

}
if(isset($_GET['del_id']) && ($_GET['del_id'] != '')){
$del_id = $_GET['del_id'];
$del_sql = "SELECT * FROM tbl_pdf WHERE id=".$del_id;
$del_query = mysql_query($del_sql);
$del_data = mysql_fetch_assoc($del_query);
$del_name = $del_data['pdf_name'];
$destination = "/var/chroot/home/content/78/6140178/html/bricrealty/wp-content/themes/my_theme/pdf/".$del_name;
unlink($destination);

mysql_query("DELETE FROM tbl_pdf WHERE id=".$del_id);
// header("location:/toolbox-upload/");
}
?>
 <script type="text/javascript">
function del_pdf(id){
if(confirm("Are you sure you want to delete the agent")){
	document.location.href = "/toolbox-upload/?del_id="+id+"&a=del";
} 
}

</script>


<h4 class="ttle">Delete Marketing Toolbox

<div class="tab">
	<ul>
   		<li><a href="//agent-profile">My Profile</a></li>
    	<li><a href="/agent-list">Agent List</a></li>
        <li><a href="/client-list">Client List</a></li>
        <li><a href="/manager-add">Add Administrator/Manager</a></li>
        <li><a href="/manager-list">Administrator/Manager List</a></li>
        <li><a href="/toolbox-upload">Upload Marketing Toolbox</a></li>
        <li><a href="/reset-password/">Reset Password</a></li>
        
    </ul>
  </div>
    <div class="clear"></div>
</h4>

<div class="agent_signup_pro">   
   <?php
  // $path = "http://bricrealty.com/toolbox-upload/";
   ?>
   <!--<form>
   <select name="" id="val_select" onchange="select_type(<?=$path?>)">
   		<option id="val" value="0">Select Option</option>
   		<option id="val_1" value="1">Bermuda Dunes</option>
        <option id="val_2" value="2">Lake Buena Vista Resort and Spa</option>
        <option id="val_3" value="3">Visconty Residences</option>
   </select>
   </form>-->
   
   <?php

$merketing_toolbox = array(
'BLANK' =>'Select',
'BD' =>'Bermuda Dunes',
'LB' =>'Lake Buena Vista Resort and Spa',
'VR' =>'Visconti Residences',
'WET' =>'Waters Edge Townhomes at Lake Nona',


);

?>
   <div class="row">
    
   <form name="client_form" action="" method="post" >



<input type="hidden" name="action" value="my_password_update" />
 

    <span class="one">Select Properties:</span>
    <span class="two">
    <select name="merketing_tool_box1" id="merketing_tool_box1">
    <?php 
	
	foreach($merketing_toolbox as $key => $val) {
	
	?>
    <option value="<?=$key?>"><?=$val?></option>
    
    <?php 
	}
	
	
	?>
    
    </select>
</span>

	<div style="clear:both; height:0;"></div>
 
</form>

</div>
   
      
   <div class="row" id="BD1" style="display:none">

		<span class="one"><h4 class="vr">Bermuda Dunes</h4></span>
		<span class="two">
        <div class="pdf_list">
    		
            <ul>
    
    <?php
    
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=1";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	?>
    <li><a href="<?php bloginfo('template_directory'); ?>/pdf/<?=$data['pdf_name']?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" /><?=$data['pdf_title']?></a>
    <a href="javascript:void(0);" onclick="javascript:del_pdf('<?=$data['id']?>')"><img src="<?php bloginfo('template_directory'); ?>/images/deleate_icon.png" title="delete" width="20px" /></a>
    </li>
    
    <?php } ?>
    

    </ul>
    </div>
    </span>
    <div style="clear:both; height:0;"></div>
</div>


<div class="row" id="LB1" style="display:none">
<span class="one"><h4 class="vr">Lake Buena Vista Resort and Spa</h4></span>
<span class="two">
<div class="pdf_list">
    <ul>
    	  <?php
    
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=2";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	?>
    <li><a href="<?php bloginfo('template_directory'); ?>/pdf/<?=$data['pdf_name']?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" /><?=$data['pdf_title']?></a>
    
    <a href="javascript:void(0);" onclick="javascript:del_pdf('<?=$data['id']?>')"><img src="<?php bloginfo('template_directory'); ?>/images/deleate_icon.png" title="delete" width="20px" /></a></li>
    
    <?php } ?>
       
     
    </ul>
    </div>
    </span>
    <div style="clear:both; height:0;"></div>
</div>


<div class="row" id="VR1" style="display:none">
<span class="one"><h4 class="vr">Visconty Residences</h4></span>
<span class="two">
<div class="pdf_list">
    <ul>
             <?php
    
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=3";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	$url="http://bricrealty.com/pdf/".$data['pdf_name'];
	?>
    <li><a href="<?=$url?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" /><?=$data['pdf_title']?></a> 
    <a href="javascript:void(0);" onclick="javascript:del_pdf('<?=$data['id']?>')"><img src="<?php bloginfo('template_directory'); ?>/images/deleate_icon.png" title="delete" width="20px" /></a>
    </li>
    
    <?php } ?>
	</ul>
    </div>
    </span>
     <div style="clear:both; height:0;"></div>
</div>


<div class="row" id="WET" style="display:none">
<span class="one"><h4 class="vr">Waters Edge Townhomes at Lake Nona</h4></span>
<span class="two">
<div class="pdf_list">
    <ul>
             <?php
    
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=4";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	$url="http://bricrealty.com/pdf/".$data['pdf_name'];
	?>
    <li><a href="<?=$url?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" /><?=$data['pdf_title']?></a> 
    <a href="javascript:void(0);" onclick="javascript:del_pdf('<?=$data['id']?>')"><img src="<?php bloginfo('template_directory'); ?>/images/deleate_icon.png" title="delete" width="20px" /></a>
    </li>
    
    <?php } ?>
	</ul>
    </div>
    </span>
     <div style="clear:both; height:0;"></div>
</div>



<br clear="all"  />
</div>
   
</div>   
   
  <br clear="all"  />
</div> 
   
   
   <?php
   
   $sql_list = "SELECT * FROM tbl_pdf";
   
   ?>
   
    
<?php //} ?>



<?php get_footer(); ?>