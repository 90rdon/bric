<?php
/*



Template name: Custom My Training Page



*/
ob_start();
get_header(); 
if(!$_SESSION['is_login']) {
header("Location:/agent-login");
exit;

}
?>
<?php
if(isset($_POST['submit']) && $_POST['submit'] == 'SUBMIT'){

$my_training_title = $_POST['my_training_title'];


if(is_uploaded_file($_FILES['my_training_file']['tmp_name'])){

$tmp_name = $_FILES['my_training_file']['tmp_name'];

$name = $_FILES['my_training_file']['name'];

$uploads_dir = '/var/chroot/home/content/78/6140178/html/bricrealty/wp-content/themes/my_theme/my_training/'.$name;

move_uploaded_file($tmp_name,$uploads_dir);


$image_tmp_name = $_FILES['my_training_image_file']['tmp_name'];

$image_name = $_FILES['my_training_image_file']['name'];

$image_uploads_dir = '/var/chroot/home/content/78/6140178/html/bricrealty/wp-content/themes/my_theme/my_training/image/'.$image_name;

move_uploaded_file($image_tmp_name,$image_uploads_dir);

$sql = "INSERT INTO 
 `tbl_my_training` SET
				`my_training_title` = '$my_training_title',
				`my_training_name` = '$name',
				`image` = '$image_name'
 ";

 mysql_query($sql);

 }
}
?>
 
<?php
if($_SESSION['broker_type']=='M'){
?>
<div class="agent_prof">
<h4 class="ttle">My Training

<div class="tab">
	<ul>
    	<li><a href="/agent-list"><b>Agents List</b></a></li>
		<li><a href="/client-list"><b>Client List</b></a></li>
        <li><a href="/my-documents"><b>My Documents</b></a></li>
        <li><a href="/my-training"><b>My Training</b></a></li>
         <li><a href="/profile-edit">Edit Profile</a></li>
        <li><a href="/reset-password/"><b>Reset Password</b></a></li>
    </ul>
</div>
    <div class="clear"></div>
</h4>



<form name="my_training_upload" action="" method="post" enctype="multipart/form-data">   
    <div class="agent_signup_pro">
		

<div class="row listingcnt grey">
    	<span class="one">Title of My Training :</span>
        <span class="two"><input type="text" name="my_training_title" /></span>
        <div style="clear:both; height:0;"></div>
</div>
   
<div class="row listingcnt">
    	<span class="one">Video Image :</span>
        <span class="two"><input type="file" name="my_training_image_file"/></span>
        <div style="clear:both; height:0;"></div>
</div>
    
<div class="row listingcnt">
    	<span class="one">Browse Video :</span>
        <span class="two"><input type="file" name="my_training_file"/></span>
        <div style="clear:both; height:0;"></div>
</div>
    
<div class="row listingcnt grey">
    	
    	<span class="two"><input type="submit" name="submit" value="SUBMIT" class="sub_btn" /></span>
        <div style="clear:both; height:0;"></div>
</div>
 </div>   
   </form>

</div>

<?php
}elseif($_SESSION['broker_type']=='AD'){
?>
<div class="agent_prof">
<h4 class="ttle">My Training

<div class="tab">
	<ul>
   
    	<li><a href="/agent-list"><b>Agent List</b></a></li>
        <li><a href="/client-list"><b>Client List</b></a></li>
        <li><a href="/manager-add"><b>Add Administrator/Manager</b></a></li>
        <li><a href="/manager-list"><b>Administrator/Manager List</b></a></li>
        <li><a href="/toolbox-upload"><b>Upload Marketing Toolbox</b></a></li>
        <li><a href="/my-documents"><b>My Documents</b></a></li>
        <li><a href="/my-training"><b>My Training</b></a></li>
        <li><a href="/profile-edit"><!--<img src="<?php bloginfo('stylesheet_directory'); ?>/images/edit_icon.png" /> -->Edit Profile</a></li>
        <li><a href="/reset-password/"><b>Reset Password</b></a></li>
        
    </ul>
</div>
    <div class="clear"></div>
</h4>

<div class="training_container">

<?php

$q=mysql_query("SELECT * FROM tbl_my_training");
$r=mysql_num_rows($q);
?>


<?php
if($r>0)
{
?>

<div class="training_video">Training Video</div><div class="training_title">Training Title</div>
<?php
$i = 0 ;
while($f=mysql_fetch_array($q))

{
?>
<div class="training_list">
<div class="training_video">
<div id="myElement<?php echo $i;?>">Loading the player...</div>

<script type="text/javascript">
    jwplayer("myElement<?php echo $i;?>").setup({
        file: "<?php echo get_template_directory_uri(); ?>/my_training/<?php echo $f['my_training_name'];?>",
        image: "<?php echo get_template_directory_uri(); ?>/my_training/image/<?php echo $f['image'];?>"
    });
</script>

</div>
<div class="training_title">
<?php echo $f['my_training_title'];?>
</div>

<div class="clear"></div>
</div>

<?php $i++; } ?>

<?php
}
else
{
?>
<p>Empty database</p>
<?php
}
?>


<div class="clear"></div>
<a id="add_training" class="add_training" href="javascript:viod()">Add Training</a>
</div>


<div id="training_add" class="training_add" style="display:none;">
<form name="my_training_upload" action="" method="post" enctype="multipart/form-data">   
    <div class="agent_signup_pro">
		

<div class="row listingcnt grey">
    	<span class="one">Title of My Training :</span>
        <span class="two"><input type="text" name="my_training_title" /></span>
        <div style="clear:both; height:0;"></div>
</div>

<div class="row listingcnt">
    	<span class="one">Video Image :</span>
        <span class="two"><input type="file" name="my_training_image_file"/></span>
        <div style="clear:both; height:0;"></div>
</div>

<div class="row listingcnt">
    	<span class="one">Browse Video :</span>
        <span class="two"><input type="file" name="my_training_file"/></span>
        <div style="clear:both; height:0;"></div>
</div>
    
<div class="row listingcnt grey">
    	
    	<span class="two"><input type="submit" name="submit" value="SUBMIT" class="sub_btn" /></span>
        <div style="clear:both; height:0;"></div>
</div>
 </div>   
   </form>
</div>

</div>
<?php
}
?>
<?php get_footer(); ?>