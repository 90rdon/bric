<?php
/*
Template name: custom_agent_welcome_page
*/
ob_start();
get_header();
?>
<div class="agent_prof">
<h4 class="ttle">WELCOME
<div class="clear"></div>
</h4>

<div class="agent_signup_pro">
<div class="row grey" style="padding: 49px;
    text-align: center;">
<span class="bold">Thank you</span> for registering as a preferred agent with bricrealty.<a href="/agent-login">"Click Here Now"</a> to gain access to your new account.
</div>
</div>
</div>
<?php get_footer(); ?>