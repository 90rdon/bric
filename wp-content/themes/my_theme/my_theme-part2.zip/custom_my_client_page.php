<?php
/*



Template name: Custom My Client



*/
ob_start();
get_header(); 
if(!$_SESSION['is_login']) {
header("Location:/agent-login");
exit;

}


 if(isset($_REQUEST['del_action']) && ($_REQUEST['del_action'] == 'all')){
$del_data = $_POST['del_data'];
	foreach($del_data as $id){
	//echo $id.'<br />';
		mysql_query("DELETE FROM tbl_client WHERE client_id=$id");
	}
	//header("Location:/client-list/?t=".$_GET['t']);
}


if(isset($_GET['id']) && $_GET['id'] !="") {
$borker_id = $_GET['id'];
}  else {
$borker_id = $_SESSION['id'];
}
 if(isset($_GET['t'])) {
  	$page1 = $_GET['t'];
  } else {
  	$page1 = 1;
  }
  
 
 $extra_url='?';
  if(isset($_GET['id']) && ($_GET['id']!='') ){
  $extra_url='?id='.$_GET['id'].'&';
  
  }
  
  $targetpage = '/my-client/'.$extra_url;
  $tbl_name1 = 'tbl_client';
  $where = " WHERE`broker_id`=$borker_id $short_by $order_by";
  
  $adj =8;
  
  $limit = 5;
  
  
  $p =  pagenation($page1,$limit,$targetpage, $adj,$tbl_name1 ,$where);
  $start = $p['start'];

	/*insert session value for dynamic*/
	//var_dump($p);
	
	
	$o_by = 'name';
	$type = 'ASC';
	
	if(isset($_POST['fn']) && ($_POST['fn']=='First Name')){
	
	$o_by = 'name';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
		
		if(isset($_POST['fn']) && ($_POST['fn']=='Last Name')){
	
	$o_by = 'last_name';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
		
		if(isset($_POST['fn']) && ($_POST['fn']=='Spouse')){
	
	$o_by = 'Spouse';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
		
		if(isset($_POST['fn']) && ($_POST['fn']=='Address')){
	
	$o_by = 'address';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}

if(isset($_POST['fn']) && ($_POST['fn']=='City')){
	
	$o_by = 'city';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
		
		if(isset($_POST['fn']) && ($_POST['fn']=='State')){
	
	$o_by = 'state';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
		
		if(isset($_POST['fn']) && ($_POST['fn']=='Zip Code')){
	
	$o_by = 'zip_code';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
		
		if(isset($_POST['fn']) && ($_POST['fn']=='Country')){
	
	$o_by = 'country';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
	
	
	if(isset($_POST['fn']) && ($_POST['fn']=='Phone')){
	
	$o_by = 'phone';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
		
		if(isset($_POST['fn']) && ($_POST['fn']=='Email')){
	
	$o_by = 'email';
	
		if(isset($_SESSION['fn']) && ($_SESSION['fn'] === 0 || $_SESSION['fn'] ==1)){
		
			if($_SESSION['fn']==1){
			
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		
		}elseif($_SESSION['fn']==0){
			
			
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		
		
		
		}else{
		if($_POST['fn']==1){
			$_SESSION['fn'] = 0;
			$type = 'ASC';
		}elseif($_POST['fn']==0){
			$_SESSION['fn'] = 1;
			$type = 'DESC';
			
		}
		}
		}
	
	$ob=' ORDER BY '.$o_by.' '.$type.' ';
	
	 $sql = "SELECT * FROM $tbl_name1 WHERE`broker_id`=$borker_id ".$ob." LIMIT $start , $limit";
	/*print $sql;
	exit;*/
	$result = mysql_query($sql);
	
	
	
	$broker_sql = 'SELECT * FROM tab_broker WHERE broker_id ='.$borker_id;

$broker_rs = mysql_query($broker_sql);
$broker_row = mysql_fetch_assoc($broker_rs);
	
	
	
	if(isset($_POST['client_csv_upd']) && ($_POST['client_csv_upd']=='Upload')){

if(is_uploaded_file($_FILES['csv_upd']['tmp_name'])){
$file_tmp_name = $_FILES['csv_upd']['tmp_name'];
//$file_name = $_FILES['csv_upd']['name'];
$image1 = str_replace(" ","_",$_FILES['csv_upd']['name']);
$ext = stristr($image1,'.');
$file_name = 'uploaded_client_list_'.time().$ext;
$destination = '/var/chroot/home/content/78/6140178/html/bricrealty/wp-content/themes/my_theme/csv_upload/my_client/'.$file_name;
if(move_uploaded_file($file_tmp_name,$destination)){
$file = fopen("/var/chroot/home/content/78/6140178/html/bricrealty/wp-content/themes/my_theme/csv_upload/my_client/".$file_name,"r");
$k=1;
while(! feof($file))
  {
 /* print '<pre>';
  print_r(fgetcsv($file));
  print '</pre>';*/
  $datass = fgetcsv($file);
  
  
   $name = $datass[0];
  $last_name = $datass[1];
  $Spouse = $datass[2];
  $broker_id = $datass[3];
  $address = $datass[4];
  $city = $datass[5];
  $state = $datass[6];
  $country = $datass[7];
  $zip_code = $datass[8];
  $phone = $datass[9];
  $email = $datass[10];
  $product_type = $datass[11];
  $create_date = date('Y-m-d H:i:s',strtotime($datass[12]));
  
  
  
  
  
  if($name != '' && $last_name != '' && $broker_id != '' && $address != '' && $city != '' && $state != '' && $country != '' && $zip_code != '' && $phone != '' && $email != '' && $product_type != '' && $create_date != ''){
  if($k>1){
 $query = "INSERT INTO tbl_client SET name='$name',last_name='$last_name',
 Spouse='$Spouse',broker_id='$broker_id',
 address='$address',city='$city',
 state='$state',country='$country',
 zip_code='$zip_code',phone='$phone',
 email='$email',product_type='$product_type',
 create_date= '$create_date'
 ";
 
  mysql_query($query);
  }
  }
  
  
  $k++;
  }

fclose($file);

}

	
	
}

}	
	
	
	
	
	

?>
<script type="text/javascript">
function del_client(id){
if(confirm("Are you sure you want to delete the client")){
	document.location.href = "/my-client-edit/?id="+id+"&a=del";
} 
}






</script>
<script type="text/javascript">
$jq(document).ready(function(){
$jq('#chckHead').click(function () {
if (this.checked == false) {
$jq('.chcktbl:checked').attr('checked', false);
}
else {
//alert("Shankajit B");
$jq('.chcktbl:not(:checked)').attr('checked', true);
}
});
});
</script>
<script type="text/javascript">
function del_all_client(id,p){
var inputElems = document.getElementsByTagName("input"),
    count = 0;
for(var i=0; i<inputElems.length; i++) {
    if (inputElems[i].type === "checkbox" && inputElems[i].checked === true) {
        count++;
		
    }
} 
if(count ==1){
	var msg = "Are you sure you want to delete The Selected Record";
}else{
	var msg = "Are you sure you want to delete All "+count+" Selected Records?";
}
if(confirm(msg)){
	//document.location.href = "/client-list/?t="+p+"&del_action=all";
	
	document.location.href = "/my-client/?id="+id+"&t="+p+"&del_action=all";
}
}

</script>

<h4 class="ttle">CLIENT LIST
  <?php if( $_SESSION['broker_type']=='A'){?>
  <div class="tab">
    <ul>
      <li><a href="agent-profile"><strong>My Profile</strong></a></li>
      <li><a href="/marketing-toolbox"><b>Marketing Toolbox</b></a></li>
      <li><a href="/my-client-add"><b>Add Client </b></a></li>
      <li><a href="/reset-password/"><b>Reset Password</b></a></li>
    </ul>
  </div>
  <?php
} else if ($_SESSION['broker_type']=='M') {
?>
  <div class="tab">
    <ul>
      <li><a href="/agent-profile"><strong>My Profile</strong></a></li>
      <li><a href="/agent-list"><b>Agents List</b></a></li>
      <li><a href="/client-list"><b>Client List</b></a></li>
      <li><a href="/reset-password/"><b>Reset Password</b></a></li>
    </ul>
  </div>
  <?php }else if ($_SESSION['broker_type']=='AD') {
 ?>
  <div class="tab">
    <ul>
      <li><a href="/agent-profile"><strong>My Profile</strong></a></li>
      <li><a href="/agent-list"><b>Agent List</b></a></li>
      <li><a href="/client-list"><b>Client List</b></a></li>
      <li><a href="/manager-add"><b>Add Administrator/Manager</b></a></li>
      <li><a href="/manager-list"><b>Administrator/Manager List</b></a></li>
      <li><a href="/toolbox-upload"><b>Upload Marketing Toolbox</b></a></li>
      <li><a href="/reset-password/"><b>Reset Password</b></a></li>
    </ul>
  </div>
  <?php
  }
  ?>
  <div class="clear"></div>
</h4>
<form name="" method="post" enctype="multipart/form-data">
  <h4 class="ttle"> Agent Name :
    <?=$broker_row['broker_name']?>
    <div class="tab items">
      <ul>
        <?php
	if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){
	?>
        <li class="dltbtn">
          <?php
	if(isset($_GET['t']) && ($_GET['t'] != '')){
		$page_num = $_GET['t'];
	}else{
		$page_num = 1;
	}
?>
          <a class="delete_selected_val" href="javascript:void(0);" onclick="javascript:del_all_client('<?=$broker_row['broker_id']?>','<?=$page_num?>')"> <img src="<?php bloginfo('template_directory'); ?>/images/deleate_icon.png" title="delete" height="26px" /> </a>
          <input type="hidden" name="action" value="all" />
        </li>
        <li>
          <div align='center'><font color='#E67100'size="+1"><a href="/client_list_csv/?t=<?=$_GET['id']?>&action=myclient_exp">Export</a></font></div>
        </li>
        <li class="uploadng">
          <input type="file" name="csv_upd" size="10" class="filefld" />
          <input type="submit" name="client_csv_upd" value="Upload" class="filesbmt" />
        </li>
        <?php } ?>
      </ul>
    </div>
  </h4>
  
  
  
  
  
  
  	<?php
	if($_SESSION['broker_type']=='AD'){
	?>
	
  <div class="agent_signup_pro myclienslst administrator">
 	
    <?php 
	}if($_SESSION['broker_type']=='M'){
	?> 
  <div class="agent_signup_pro myclienslst manager">
  
  	<?php
	}if($_SESSION['broker_type']=='A'){
	?>
  <div class="agent_signup_pro myclienslst agent">
  	<?php
	}
	?>
  
  <div class="row">
    <?php
	if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){
	?>
    <span class="one slct">
    <?php
        $url = $_SERVER[REQUEST_URI];
		$search = strpos($url,'?');
		if($search>0){
			$extra_parts = '&';
		}else{
			$extra_parts = '?';
		}
		$final_url = $url.$extra_parts.'action=all';
		if(isset($_GET['action']) && ($_GET['action'] == 'all')){
			$final_url = str_replace('action=all','',$final_url);
			$final_url = str_replace('&&','',$final_url);
			$final_url = str_replace('?&','',$final_url);
		}
		?>
    <input class="chcktbl" type="checkbox" id="chckHead" />
    </span>
    <?php } ?>
    
    
    <span class="one fname">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="First Name" />
    </span>
    
    <span class="one lname">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="Last Name" />
    </span>
    
    <span class="one spouse">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="Spouse" />
    </span>
    
    <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
    <span class="one address">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="Address" />
    </span>
    <?php } ?>
    
    
    <span class="one city">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="City" />
    </span>
    
    <span class="one state">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="State" />
    </span>
    
    <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
    <span class="one zip">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="Zip" />
    </span>
    <?php } ?>
    
    <span class="one country">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="Country" />
    </span>
    
    <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
    <span class="one phone" style="width:70px;">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="Phone" />
    </span>
    <?php } ?>
    
    
    <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
    <span class="one email">
    <input type="submit" name="fn" id="fn" onclick="change_val()" class="point" value="Email" />
    </span>
    <?php } ?>
    
    <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
    <span class="one date">Date</span>
    <?php } ?>
    
    
    <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
    <span class="one action">Action</span>
    <?php }	?>
    
    
    <div class="clear"></div>
  </div>
  <?php
$i=1;
?>
  <?php while($row=mysql_fetch_array($result))
{
$create_date=$row['create_date'];

?>
<?php if($i%2==0){?>
  <div class="row listingcnt grey">
<?php } ?>

<?php if($i%2==1){ ?>
    <div class="row listingcnt">
<?php } ?>
      
      
	  <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){ ?>
      <span class="one slct">
      <input class="chcktbl" type="checkbox"  id="del_all_<?=$row['client_id']?>" name="del_data[<?=$row['client_id']?>]" value="<?=$row['client_id']?>"/>
      </span>
      <?php } ?>
      
      <span class="one fname"><?php echo $row['name']; ?></span>
      <span class="one lname"><?php echo $row['last_name']; ?></span>
      <span class="one spouse"><?php echo $row['Spouse']; ?></span>
      
	  <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
      <span class="one address"><?php echo $row['address']; ?></span>
      <?php } ?>
      
      <span class="one city"><?php echo $row['city']; ?></span>
      <span class="one state"><?php echo $row['state']; ?></span>
      
	  
	  <?php	if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
      <span class="one zip"><?php echo $row['zip_code']; ?></span>
      <?php } ?>
      
      <span class="one country"><?php echo $row['country']; ?></span>
	  
	  <?php	if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
      <span class="one phone"><?php echo $row['phone']; ?></span>
      <span class="one email"><?php echo $row['email']; ?></span>
      <?php } ?>
      
      
      <?php if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
      <span class="one date">
     
	<?php
	/*echo strftime("%b/%d/%G %T",$create_date);*/
	echo date("m/d/Y", strtotime($create_date));
	 $h = date("H",strtotime($create_date));
	$m= date("i",strtotime($create_date));
	 $s= date("s",strtotime($create_date));
     echo "-";
	echo date("H:i:s",mktime($h, $m,$s, 7, 1, 2000));  
	
	?>
      </span>
      <?php }?>
      
      
      <?php	if($_SESSION['broker_type']=='AD' || $_SESSION['broker_type']=='A'){?>
      <span class="one action">
      <a href="my-client-edit/?id=<?=$row['client_id']?>" style="margin-right:10px;"><img src="<?php bloginfo('template_directory'); ?>/images/edit_icon.png" title="edit" width="20px" /></a>
      <a href="javascript:void(0);" onclick="javascript:del_client('<?=$row['client_id']?>')"><img src="<?php bloginfo('template_directory'); ?>/images/deleate_icon.png" title="delete" width="20px" /></a></span>
      <?php }?>
      
      <div class="clear"></div>
    </div>
    

    <?php
$i++;
 }
 ?>
    <input type="hidden" name="check_count" id="check_count" value="<?=$mn?>">
  </div>
</form>
<?php echo $p['pagenation'];?>
<?php get_footer(); ?>
