<?php
/*



Template name: Custom Marketing Tool Box



*/
ob_start();
get_header(); 
if(!$_SESSION['is_login']) {
header("Location:/agent-login");
exit;

}
?>


<?php

$msg =0;
$sql = "SELECT * FROM tab_broker WHERE`broker_id` =".$_SESSION['id'];
$rs = mysql_query($sql);
/*	print $sql;
	exit*/;
	$result = mysql_query($sql);
	
	$row = mysql_fetch_assoc($result);

?>



<h4 class="ttle">Marketing Toolbox

<div class="tab">
	<ul>
	
	     <li><a href="agent-profile"><strong>Agent Profile</strong></a></li>
    	<li><a href="/my-client-add"><b>Add Client </b></a></li>
        <li><a href="/my-client"><b>My Clients</b></a></li>
         <li><a href="/reset-password/"><b>Reset Password</b></a></li>
        
    </ul>
    <div class="clear"></div>
</div>
</h4>


<div class="agent_signup_pro">






<?php

$merketing_toolbox = array(
'BLANK' =>'Select',
'BD' =>'Bermuda Dunes',
'LB' =>'Lake Buena Vista Resort and Spa',
'VR' =>'Visconti Residences',
'WET' =>'Waters Edge Townhomes at Lake Nona',

);

?>


 
  
<div class="row">
<form name="client_form" action="" method="post" >
<input type="hidden" name="action" value="my_password_update" />
<span class="one">Select Properties:</span> 
<span class="two"><select name="merketing_tool_box1" id="merketing_tool_box">
    <?php 
	
	foreach($merketing_toolbox as $key => $val) {
	
	?>
    <option value="<?=$key?>"><?=$val?></option>
    
    <?php 
	}
	
	
	?>
    
    </select>
</span>

<div style="clear:both; height:0;"></div>
 
</form>

</div>


<div class="row" id="BD" style="display:none">
<span class="one"><h4 class="vr">Bermuda Dunes</h4></span>
<span class="two">
<div class="pdf_list">
    
<ul>    
    <?php
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=1";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	$url="http://bricrealty.com/wp-content/themes/my_theme/pdf/".$data['pdf_name'];
	?>
	<li><a href="<?=$url?>" target="_blank">
		<img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" />
		<?=$data['pdf_title']?>
	</a></li>
   <?php } ?>
    
</ul>
</div>    
</span>
<div style="clear:both; height:0;"></div>
</div>


<div class="row" id="LB" style="display:none">
<span class="one"><h4 class="vr">Lake Buena Vista Resort and Spa</h4></span>
<span class="two">
<div class="pdf_list">
    <ul>
    	  <?php
    
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=2";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	$url="http://bricrealty.com/wp-content/themes/my_theme/pdf/".$data['pdf_name'];
	?>
    <li><a href="<?=$url?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" /><?=$data['pdf_title']?></a></li>
    
    <?php } ?>
       
     
    </ul>
</div>
</span>
<div style="clear:both; height:0;"></div>
</div>

<div class="row" id="VR" style="display:none">
<span class="one"><h4 class="vr">Visconty Residences</h4></span>
<span class="two">
<div class="pdf_list">
    <ul>
             <?php
    
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=3";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	$url="http://bricrealty.com/wp-content/themes/my_theme/pdf/".$data['pdf_name'];
	?>
    <li><a href="<?=$url?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" /><?=$data['pdf_title']?></a></li>
    
    <?php } ?>
	</ul>
</div>
</span>
<div style="clear:both; height:0;"></div>
</div>


<div class="row" id="WET" style="display:none">
<span class="one"><h4 class="vr">Waters Edge Townhomes at Lake Nona</h4></span>
<span class="two">
<div class="pdf_list">
    <ul>
             <?php
    
	$sql = "SELECT * FROM tbl_pdf WHERE toolbox_type=4";
	$query = mysql_query($sql);
	while($data = mysql_fetch_assoc($query)){
	$url="http://bricrealty.com/wp-content/themes/my_theme/pdf/".$data['pdf_name'];
	?>
    <li><a href="<?=$url?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/images/images.jpg" title="edit" height="20px" width="20px" /><?=$data['pdf_title']?></a></li>
    
    <?php } ?>
	</ul>
</div>
</span>
<div style="clear:both; height:0;"></div>
</div>





<br clear="all"  />

</div>

<br clear="all"  />
</div>
<?php get_footer(); ?>