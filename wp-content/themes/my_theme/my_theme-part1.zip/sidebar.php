<!--<div id="left-section">
  <div class="intro-module">
    <div class="intro-wrapper home"> <span class="intro-title">
      <h1>Welcome</h1>
      </span>
 <div class="welcome">     
	  <?php 
// Custom widget Area Start
//if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Welcome') ) : ?>
<?php //endif;
// Custom widget Area End
?>
</div>
	  
      <a class="intro-yellow-key-link" href="<?php echo get_page_link(22); ?>" align="center">BRIC REALTY</a> </div>
  </div>
</div>-->